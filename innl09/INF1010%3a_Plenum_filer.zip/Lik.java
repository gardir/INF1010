interface Lik {
    public boolean samme( String navn );
}
