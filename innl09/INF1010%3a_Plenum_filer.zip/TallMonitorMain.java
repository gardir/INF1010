public class TallMonitorMain {

	private static void test( boolean faktisk, boolean forventet, String forklaring ) {
		System.out.print( "Tester " + forklaring + ": ");
		if ( faktisk == forventet ) {
			System.out.println("Passerte");
		} else {
			System.out.format("Feilet (fikk %b vs. %b forventet)\n", faktisk, forventet);
		}
	}

	private static void testMonitor() {
		TallMonitor monitor = new TallMonitor();
		test( monitor.settMinste(0), true, "Setter inn foerste minste tall" );
		test( monitor.settStorste(2), true, "Setter inn foerste storste tall" );
		test( monitor.settStorste(-1), false, "Setter inn feil storste tall" );
		test( monitor.settMinste(3), false, "Setter inn feil minste tall" );
	}

	private static void trix8_1( int min, int max ) {
		TallMonitor monitor = new TallMonitor( min, max );
		monitor.skrivUtTall();
		
		Thread nedover = (new Thread( new Nedover(0, monitor) ) );
		nedover.start();
		
		Thread oppover = (new Thread( new Oppover(1, monitor) ) );
		oppover.start();

	}
	
	public static void main(String[] args) {
		//testMonitor();
		boolean defaultRun = true;
		if ( args.length > 1 ) {
			try {
				trix8_1( Integer.parseInt( args[0] ), Integer.parseInt( args[1] ) );
				defaultRun = false;
			} catch ( NumberFormatException e ) {
				System.out.format("Feil verdi på args[0]: %s og args[1]: %s\n", args[0], args[1] );
			} catch ( ArrayIndexOutOfBoundsException e ) {
				System.out.format("Ikke nok argumenter, minst to tall\n" );
			}
		}
		if ( defaultRun ) {
			trix8_1( Integer.MIN_VALUE>>1, Integer.MAX_VALUE>>1 );
		}
	}

	private static class Nedover implements Runnable {
		private int traadIndeks;
		private TallMonitor monitor;
		
		public Nedover( int indeks, TallMonitor monitor ) {
			this.traadIndeks = indeks;
			this.monitor = monitor;
		}
		
		public void run() {
			System.out.println( "Nedover#" + traadIndeks );
			int i = Integer.MAX_VALUE;
			while ( monitor.settStorste( i ) ) {
				i--;
			}
			System.out.format( "NEDOVER#%d: Siste storste tall ble: %d\n", traadIndeks, i );
			monitor.skrivUtTall();
		}
		
	}

	private static class Oppover implements Runnable {
		private int traadIndeks;
		private TallMonitor monitor;

		public Oppover( int indeks, TallMonitor monitor ) {
			this.traadIndeks = indeks;
			this.monitor = monitor;
		}
		
		public void run() {
			System.out.println( "Oppover#" + traadIndeks );
			int i = Integer.MIN_VALUE;
			while ( monitor.settMinste( i ) ) {
				i++;
			}
			System.out.format( "OPPOVER#%d: Siste minste tall ble: %d\n", traadIndeks, i );
			monitor.skrivUtTall();
		}
		
	}
	
}
