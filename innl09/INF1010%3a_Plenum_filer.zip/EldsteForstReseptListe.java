public class EldsteForstReseptListe extends EnkelReseptListe {

	// Denne er lik til EnkelReseptListe
	
}
