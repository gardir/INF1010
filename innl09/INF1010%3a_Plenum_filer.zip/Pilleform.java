interface Pilleform {
    
    /**
     * Henter antallet piller totalt
     */
    public int hentPilleAntall();

    /**
     * Henter virkestoff per pille
     */
    public double hentVirkestoffPrPille();

}
