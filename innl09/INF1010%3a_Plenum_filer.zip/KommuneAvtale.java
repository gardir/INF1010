interface KommuneAvtale {
    public int hentAvtale();
}
