interface Miksturform {

    /**
     * Henter volumet i flasken.
     */
    public double hentVolum();

    /**
     * Henter virkestoff pr volum
     */
    public double hentVirkestoffPrVolum();

}
